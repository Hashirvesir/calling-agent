"""Telnyx Programmable Voice webhooks + WebSocket media stream.

Multi-tenant routing:
    POST /webhook/{webhook_token}  — per-user webhook URL
    WS   /ws                       — Telnyx media stream → pipecat pipeline
    POST /dial                     — Initiate outbound call (requires JWT)
"""

import asyncio
import base64
import json
import os
import re
import time
from datetime import datetime, timezone
from urllib.parse import quote, unquote

import aiohttp
from fastapi import APIRouter, Depends, Form, HTTPException, Request, WebSocket
from fastapi.responses import JSONResponse
from loguru import logger

from pipecat.runner.types import WebSocketRunnerArguments

from app.services.bot import bot
from app.core.auth import get_current_user
from app.core.database import (
    create_call, update_call, end_call, get_call_id_by_ccid,
    log_event, upload_recording, get_agent_by_number,
    get_call_agent_and_script, get_caller_history,
    get_user_by_webhook_token, get_user_settings,
)
from app.core.config import settings

router = APIRouter(tags=["telnyx"])

TELNYX_API = "https://api.telnyx.com/v2"
_WEBHOOK_TOLERANCE_SECS = 300

# ---------------------------------------------------------------------------
# Webhook signature verification (Ed25519)
# ---------------------------------------------------------------------------

def _verify_webhook_signature(body: bytes, timestamp: str, signature_b64: str, pub_key_b64: str) -> bool:
    if not pub_key_b64:
        logger.warning("No webhook public key — skipping signature verification")
        return True
    try:
        ts = int(timestamp)
        if abs(time.time() - ts) > _WEBHOOK_TOLERANCE_SECS:
            logger.warning(f"Webhook timestamp too old: {ts}")
            return False
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
        pub_bytes = base64.b64decode(pub_key_b64)
        public_key = Ed25519PublicKey.from_public_bytes(pub_bytes)
        message = f"{timestamp}|".encode() + body
        public_key.verify(base64.b64decode(signature_b64), message)
        return True
    except Exception as exc:
        logger.warning(f"Webhook signature invalid: {exc}")
        return False

# ---------------------------------------------------------------------------
# Persistent aiohttp session
# ---------------------------------------------------------------------------

_telnyx_session: aiohttp.ClientSession | None = None

async def _get_telnyx_session() -> aiohttp.ClientSession:
    global _telnyx_session
    if _telnyx_session is None or _telnyx_session.closed:
        _telnyx_session = aiohttp.ClientSession()
    return _telnyx_session

# ---------------------------------------------------------------------------
# Post-call extraction
# ---------------------------------------------------------------------------

_extraction_done: set[str] = set()

async def _trigger_extraction_after_call(call_control_id: str) -> None:
    if not call_control_id or call_control_id in _extraction_done:
        return
    _extraction_done.add(call_control_id)
    if len(_extraction_done) > 1000:
        _extraction_done.clear()
        _extraction_done.add(call_control_id)

    await asyncio.sleep(5)
    try:
        data = await get_call_agent_and_script(call_control_id)
        if not data:
            return

        call_id = data.get("call_id")
        agent_name = data.get("agent_name", "unknown_agent")
        extraction_fields = data.get("extraction_fields") or []

        if not call_id or not extraction_fields:
            return

        from app.extraction.models import ExtractionSchema
        from app.extraction.service import get_extraction_service

        schema = ExtractionSchema.from_raw(agent_name, extraction_fields)
        service = get_extraction_service()
        result = await service.extract(schema=schema, call_id=call_id)
        logger.info(
            f"Auto-extraction done: agent={agent_name} call_id={call_id} "
            f"confidence={result.confidence} missing={result.missing_fields}"
        )
    except Exception as exc:
        logger.error(f"Auto-extraction failed for {call_control_id[:14]}: {exc}")

_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")

_active_ws: set[str] = set()
_outbound_registry: dict[str, tuple[str, float]] = {}  # ccid → (from_number, timestamp)
_OUTBOUND_TTL = 120

# ---------------------------------------------------------------------------
# Telnyx helpers — accept per-user api_key
# ---------------------------------------------------------------------------

async def _telnyx_post(path: str, payload: dict, api_key: str) -> tuple[int, dict | str]:
    url = f"{TELNYX_API}{path}"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    session = await _get_telnyx_session()
    async with session.post(url, json=payload, headers=headers) as resp:
        text = await resp.text()
        try:
            body = json.loads(text)
        except json.JSONDecodeError:
            body = text
        if resp.status >= 300:
            if resp.status == 422:
                logger.debug(f"Telnyx POST {path} 422: {text[:80]}")
            else:
                logger.error(f"Telnyx POST {path} failed [{resp.status}]: {text}")
        else:
            logger.info(f"Telnyx POST {path} ok: {text[:120]}")
        return resp.status, body


async def _telnyx_action(call_control_id: str, action: str, api_key: str, payload: dict | None = None):
    return await _telnyx_post(f"/calls/{call_control_id}/actions/{action}", payload or {}, api_key)


def _telnyx_error_message(status: int, body: dict | str) -> str:
    """Turn a raw Telnyx error response into one clean, actionable sentence.

    Telnyx errors look like:
        {"errors": [{"code": 10010, "detail": "Account is disabled D17 ..."}],
         "telnyx_error": {"error_code": "D17"}}
    We surface a friendly message for the common, user-fixable cases so the
    frontend can show it directly instead of dumping raw JSON.
    """
    detail = ""
    tx_code = ""
    if isinstance(body, dict):
        errs = body.get("errors") or []
        if isinstance(errs, list) and errs:
            first = errs[0] or {}
            detail = (first.get("detail") or first.get("title") or "").strip()
        tx_code = str((body.get("telnyx_error") or {}).get("error_code") or "")
    else:
        detail = str(body)[:300]

    low = detail.lower()
    if tx_code == "D17" or "account is disabled" in low or "blocked" in low:
        return (
            "Your Telnyx account is disabled or blocked (error D17). Add a payment "
            "method/balance and complete Level 2 verification in the Telnyx portal, "
            "then try again."
        )
    if status == 401 or "authenticate" in low or "unauthorized" in low or "invalid api key" in low:
        return "Telnyx rejected the API key. Check your Telnyx API Key in Settings."
    if status == 404:
        return "Telnyx could not find the call resource — check the agent's Telnyx App ID and number."
    if status == 429 or "rate limit" in low:
        return "Telnyx rate limit hit — wait a moment and try again."
    if status == 422:
        return detail or "Telnyx rejected the request (invalid number or connection settings)."
    return detail or f"Telnyx call failed (HTTP {status})."


async def _start_recording(call_control_id: str, api_key: str, delay: float = 2.0) -> None:
    await asyncio.sleep(delay)
    status, _ = await _telnyx_action(
        call_control_id, "record_start", api_key,
        {"format": "mp3", "channels": "single", "play_beep": False},
    )
    if status < 300:
        logger.info(f"Recording started for {call_control_id[:14]}…")
    else:
        logger.warning(f"record_start failed [{status}] for {call_control_id[:14]}…")


async def _download_and_store_recording(call_control_id: str, url: str) -> None:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    logger.error(f"Recording download failed [{resp.status}]: {url}")
                    return
                mp3_bytes = await resp.read()
        storage_path = await upload_recording(call_control_id, mp3_bytes)
        if storage_path:
            await update_call(call_control_id, recording_storage_path=storage_path)
            logger.info(f"Recording stored: {storage_path}")
    except Exception as exc:
        logger.error(f"Recording store error: {exc}")

# ---------------------------------------------------------------------------
# Webhook — per-user token routing
# ---------------------------------------------------------------------------

@router.get("/webhook/{webhook_token}")
@router.get("/webhook")
async def webhook_verify():
    return {"ok": True}


@router.post("/webhook/{webhook_token}")
async def webhook(webhook_token: str, request: Request):
    # Look up user by webhook_token
    try:
        user_row = await get_user_by_webhook_token(webhook_token)
    except Exception as exc:
        logger.error(f"Webhook token lookup failed (DB error): {exc}")
        raise HTTPException(503, "Service temporarily unavailable")
    if not user_row:
        raise HTTPException(403, "Unknown webhook token")

    user_id: str = user_row["user_id"]
    telnyx_api_key: str = user_row.get("telnyx_api_key") or ""
    telnyx_webhook_public_key: str = user_row.get("telnyx_webhook_public_key") or ""

    body = await request.body()
    sig = request.headers.get("telnyx-signature-ed25519", "")
    ts  = request.headers.get("telnyx-timestamp", "")
    if sig and ts:
        if not _verify_webhook_signature(body, ts, sig, telnyx_webhook_public_key):
            raise HTTPException(403, "Invalid webhook signature")

    try:
        data = json.loads(body)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning(f"Webhook body not valid JSON (user={user_id[:8]}…): {exc}")
        raise HTTPException(400, "Invalid webhook payload")

    event = data.get("data", {}) or {}
    event_type = event.get("event_type")
    payload = event.get("payload", {})
    call_control_id = payload.get("call_control_id")
    direction = payload.get("direction")
    from_num = payload.get("from")
    to_num = payload.get("to")

    logger.info(f"Telnyx event: {event_type} (user={user_id[:8]}…)")

    asyncio.create_task(log_event(
        event_type=event_type,
        call_control_id=call_control_id,
        direction=direction,
        from_number=from_num,
        to_number=to_num,
        call_leg_id=payload.get("call_leg_id"),
        occurred_at=payload.get("occurred_at"),
        raw_payload=payload,
    ))

    if event_type == "call.initiated":
        if direction == "incoming":
            agent = await get_agent_by_number(to_num, user_id) if to_num else None
            agent_id = agent.get("id") if agent else None
            asyncio.create_task(create_call(
                call_control_id=call_control_id,
                direction="inbound",
                from_number=from_num,
                to_number=to_num,
                agent_id=agent_id,
                user_id=user_id,
            ))
            try:
                ans_status, ans_body = await _telnyx_action(call_control_id, "answer", telnyx_api_key)
            except Exception as exc:
                logger.error(f"answer action could not reach Telnyx: {exc}")
                ans_status, ans_body = 502, str(exc)
            if ans_status >= 300:
                # Most common here is D17 (account disabled) or a bad API key. The
                # call can never be answered, so close the record instead of
                # leaving it stuck in "initiated".
                logger.error(f"Inbound answer failed [{ans_status}]: {_telnyx_error_message(ans_status, ans_body)}")
                if call_control_id:
                    asyncio.create_task(end_call(call_control_id, final_status="answer_failed"))

    elif event_type == "call.answered":
        if not settings.public_host:
            logger.error("PUBLIC_HOST not set — cannot start media stream")
            return {"ok": False, "error": "PUBLIC_HOST not configured"}
        asyncio.create_task(update_call(call_control_id, status="in_progress"))
        stream_url = (
            f"wss://{settings.public_host}/ws"
            f"?ccid={call_control_id}"
            f"&uid={user_id}"
            f"&dir={direction or 'incoming'}"
            f"&from_num={quote(from_num or '')}"
            f"&to_num={quote(to_num or '')}"
        )
        logger.info(f"Starting stream: {stream_url[:80]}…")
        try:
            strm_status, strm_body = await _telnyx_action(
                call_control_id, "streaming_start", telnyx_api_key,
                {
                    "stream_url": stream_url,
                    "stream_track": "inbound_track",
                    "stream_bidirectional_mode": "rtp",
                    "stream_bidirectional_codec": "PCMU",
                },
            )
        except Exception as exc:
            logger.error(f"streaming_start could not reach Telnyx: {exc}")
            strm_status, strm_body = 502, str(exc)
        if strm_status >= 300:
            logger.error(f"streaming_start failed [{strm_status}]: {_telnyx_error_message(strm_status, strm_body)}")
            if call_control_id:
                asyncio.create_task(end_call(call_control_id, final_status="stream_start_failed"))

    elif event_type == "streaming.failed":
        logger.error(f"streaming.failed: {payload}")
        if call_control_id:
            asyncio.create_task(end_call(call_control_id, final_status="stream_failed"))
            asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    elif event_type == "call.recording.saved":
        rec_urls = payload.get("recording_urls") or {}
        pub_urls = payload.get("public_recording_urls") or {}
        url = rec_urls.get("mp3") or pub_urls.get("mp3")
        if url and call_control_id:
            asyncio.create_task(_download_and_store_recording(call_control_id, url))

    elif event_type == "call.hangup":
        logger.info(f"Call ended (hangup): {call_control_id}")
        asyncio.create_task(end_call(call_control_id))
        asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    elif event_type == "streaming.stopped":
        logger.info(f"Stream stopped: {call_control_id}")
        asyncio.create_task(end_call(call_control_id))
        asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    return {"ok": True}

# ---------------------------------------------------------------------------
# WebSocket (media stream)
# ---------------------------------------------------------------------------

@router.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()

    ccid           = websocket.query_params.get("ccid")
    user_id        = websocket.query_params.get("uid")
    call_direction = websocket.query_params.get("dir", "incoming")
    from_num       = unquote(websocket.query_params.get("from_num", "")) or None
    to_num         = unquote(websocket.query_params.get("to_num",  "")) or None

    if ccid:
        logger.info(f"WebSocket: ccid={ccid[:14]}… dir={call_direction} uid={user_id}")
    else:
        logger.warning("WebSocket connected with no ccid in query params")

    is_outbound = call_direction == "outgoing"
    now = time.time()
    if not is_outbound and ccid and ccid in _outbound_registry:
        reg_from_num, reg_ts = _outbound_registry.pop(ccid)
        if now - reg_ts < _OUTBOUND_TTL:
            is_outbound = True
            if not from_num:
                from_num = reg_from_num

    stale = [k for k, (_, ts) in _outbound_registry.items() if now - ts > _OUTBOUND_TTL]
    for k in stale:
        _outbound_registry.pop(k, None)

    session_key = ccid or f"anon-{time.time()}"
    if session_key in _active_ws:
        logger.warning(f"Duplicate WebSocket for {session_key[:14]} — closing")
        await websocket.close(code=1008)
        return
    _active_ws.add(session_key)

    lookup_number = from_num if is_outbound else to_num

    # Phase 1 — these three Supabase lookups are independent. Running them together
    # costs ~one round-trip instead of three before the greeting can play.
    us_coro     = get_user_settings(user_id) if user_id else asyncio.sleep(0, result=None)
    agent_coro  = (get_agent_by_number(lookup_number, user_id)
                   if (lookup_number and user_id) else asyncio.sleep(0, result=None))
    callid_coro = get_call_id_by_ccid(ccid) if ccid else asyncio.sleep(0, result=None)
    user_row, agent, db_call_id = await asyncio.gather(us_coro, agent_coro, callid_coro)

    telnyx_api_key = (user_row.get("telnyx_api_key") or "") if user_row else ""
    if agent:
        logger.info(f"Agent matched: {agent.get('name')} (number={lookup_number})")

    # Phase 2 — caller history needs the matched agent id, so it follows Phase 1.
    caller_phone = from_num if not is_outbound else to_num
    caller_history = (
        await get_caller_history(caller_phone, agent_id=agent.get("id") if agent else None)
        if caller_phone else []
    )

    if ccid and telnyx_api_key:
        asyncio.create_task(_start_recording(ccid, telnyx_api_key))

    _hung_up = False

    async def hangup_callback():
        nonlocal _hung_up
        if ccid and not _hung_up and telnyx_api_key:
            _hung_up = True
            logger.info(f"Sending Telnyx hangup for {ccid[:14]}…")
            await _telnyx_action(ccid, "hangup", telnyx_api_key)

    runner_args = WebSocketRunnerArguments(websocket=websocket)
    runner_args.handle_sigint = False
    runner_args.pipeline_idle_timeout_secs = 60
    try:
        await bot(
            runner_args,
            hangup_callback=hangup_callback,
            is_outbound=is_outbound,
            agent=agent,
            db_call_id=db_call_id,
            call_control_id=ccid,
            caller_history=caller_history,
            caller_phone=caller_phone,
            user_id=user_id or "",
        )
    finally:
        _active_ws.discard(session_key)

# ---------------------------------------------------------------------------
# Outbound dial
# ---------------------------------------------------------------------------

@router.post("/dial")
async def dial(
    request: Request,
    to: str = Form(...),
    from_: str | None = Form(default=None, alias="from"),
    user_id: str = Depends(get_current_user),
):
    user_row = await get_user_settings(user_id)
    if not user_row or not user_row.get("telnyx_api_key"):
        raise HTTPException(400, "Telnyx API key not configured — add it in Settings")

    telnyx_api_key = user_row["telnyx_api_key"]

    to_number = to.strip()
    if not _E164_RE.match(to_number):
        raise HTTPException(400, "Phone number must be E.164 format, e.g. +923001234567")

    caller = (from_ or "").strip()
    if not caller:
        raise HTTPException(400, "Caller number required — pass 'from' or configure agent number")
    if not _E164_RE.match(caller):
        raise HTTPException(400, "From number must be E.164 format, e.g. +923001234567")
    if to_number == caller:
        raise HTTPException(400, "Cannot dial the bot's own number")

    agent = await get_agent_by_number(caller, user_id)
    telnyx_app_id = (agent.get("telnyx_app_id") if agent else None)
    if not telnyx_app_id:
        raise HTTPException(400, "No Telnyx App ID configured for this agent")

    try:
        status, body = await _telnyx_post("/calls", {
            "connection_id": telnyx_app_id,
            "to": to_number,
            "from": caller,
        }, telnyx_api_key)
    except Exception as exc:
        logger.error(f"Telnyx dial request failed to reach Telnyx: {exc}")
        raise HTTPException(502, detail="Could not reach Telnyx — check your network and try again.")

    if status >= 300:
        msg = _telnyx_error_message(status, body)
        logger.warning(f"Dial rejected by Telnyx [{status}]: {msg}")
        # Normalize odd upstream codes to a valid client/server error status.
        http_status = status if 400 <= status < 600 else 502
        raise HTTPException(http_status, detail=msg)

    outbound_ccid = (body.get("data") or {}).get("call_control_id") if isinstance(body, dict) else None
    if outbound_ccid:
        agent_id = agent.get("id") if agent else None
        asyncio.create_task(create_call(
            call_control_id=outbound_ccid,
            direction="outbound",
            from_number=caller,
            to_number=to_number,
            agent_id=agent_id,
            user_id=user_id,
        ))
        _outbound_registry[outbound_ccid] = (caller, time.time())
        logger.info(f"Outbound call registered: ccid={outbound_ccid[:14]}… to={to_number}")

    return JSONResponse({"ok": True, "telnyx": body})
