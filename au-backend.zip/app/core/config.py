"""Central settings — all environment variables in one place."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Supabase
    supabase_url: str
    supabase_anon_key: str
    supabase_service_role_key: str

    # AI services (system-level — platform pays, shared across all users)
    openai_api_key: str
    uplift_api_key: str           # Urdu TTS (Orator)
    # English TTS (ElevenLabs). voice_id is the system default; an agent may
    # override it via agents.voice_english once that holds an ElevenLabs voice ID.
    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = ""
    elevenlabs_model: str = "eleven_turbo_v2_5"

    # Server
    public_host: str = ""
    port: int = 7860

    # Uplift voice IDs — system defaults, overridable per-agent in DB
    voice_urdu_default: str = "v_8eelc901"
    voice_urdu_gen_z: str = "v_kwmp7zxt"
    voice_urdu_dada_jee: str = "v_yypgzenx"
    voice_urdu_news: str = "v_30s70t3a"
    voice_sindhi: str = "v_sd0kl3m9"
    voice_balochi: str = "v_bl1de2f7"
    voice_english: str = "v_8eelc901"

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()
