"""FastAPI application entry point.

Start with:
    python main.py
    # or
    uvicorn main:app --host 0.0.0.0 --port 7860
"""

import asyncio
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from app.core.config import settings
from app.core.database import init_db, get_all_agents, cleanup_stuck_calls
from app.services.bot import _get_agent_rag

from app.api.scripts import router as scripts_router
from app.api.agents import router as agents_router
from app.api.calls import router as calls_router
from app.api.webhooks import router as webhooks_router
from app.api.extraction import router as extraction_router
from app.api.voice_config import router as voice_config_router
from app.api.settings import router as settings_router


async def _periodic_cleanup():
    """Every 30 minutes, close calls stuck in in_progress/initiated for >60 min."""
    while True:
        await asyncio.sleep(30 * 60)
        await cleanup_stuck_calls(max_age_minutes=60)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Startup: initializing Supabase...")
    await init_db()
    await cleanup_stuck_calls(max_age_minutes=60)
    logger.info("Supabase ready — pre-warming RAG for all active agents...")

    agents = []
    for attempt in range(1, 4):
        agents = await get_all_agents()
        if agents:
            break
        if attempt < 3:
            logger.warning(f"Agent fetch attempt {attempt} returned empty — retrying in 3s...")
            await asyncio.sleep(3)

    warmed = 0
    for ag in agents:
        scripts = ag.get("scripts") or {}
        if scripts.get("content"):
            await _get_agent_rag(ag)
            logger.info(f"RAG ready for agent: {ag.get('name')}")
            warmed += 1

    if warmed:
        logger.info(f"All RAG indexes ready ({warmed} agent(s)) — server accepting calls.")
    else:
        logger.warning("No agents with scripts found — RAG will build on first call.")
    cleanup_task = asyncio.create_task(_periodic_cleanup())
    yield
    cleanup_task.cancel()


app = FastAPI(title="Invenco Call Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(scripts_router)
app.include_router(agents_router)
app.include_router(calls_router)
app.include_router(webhooks_router)
app.include_router(extraction_router)
app.include_router(voice_config_router)
app.include_router(settings_router)


if __name__ == "__main__":
    logger.info(f"Starting on port {settings.port}, PUBLIC_HOST={settings.public_host!r}")
    uvicorn.run(app, host="0.0.0.0", port=settings.port)
