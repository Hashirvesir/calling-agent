#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

import asyncio
import os
import uuid
from datetime import datetime, timezone

import aiohttp
from dotenv import load_dotenv
from loguru import logger

from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.frames.frames import Frame, LLMRunFrame, TranscriptionFrame, TTSSpeakFrame, TTSTextFrame
from pipecat.observers.loggers.debug_log_observer import DebugLogObserver, FrameEndpoint
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import LLMContextAggregatorPair
from pipecat.processors.frame_processor import FrameDirection, FrameProcessor
from pipecat.processors.frameworks.rtvi import RTVIObserver, RTVIProcessor
from pipecat.runner.types import RunnerArguments
from pipecat.runner.utils import create_transport
from pipecat.services.llm_service import FunctionCallParams
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.services.openai.stt import OpenAISTTService
from pipecat.transports.base_output import BaseOutputTransport
from pipecat.transports.base_transport import BaseTransport, TransportParams
from pipecat.transports.websocket.fastapi import FastAPIWebsocketParams

from app.services.conversation_logger import ConversationLogger
from app.services.rag import RAGContextInjector, ScriptRAG
from app.services.tts import UpliftStreamingTTSService
from app.core.voice_config import get_default_urdu_voice

load_dotenv(override=True)

# ---------------------------------------------------------------------------
# Transport configs
# ---------------------------------------------------------------------------

transport_params = {
    "webrtc": lambda: TransportParams(
        audio_in_enabled=True,
        audio_out_enabled=True,
        # 0.6 s silence — enough pause to complete Urdu/Sindhi phrases without cutting mid-word
        vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=0.6)),
    ),
    "telnyx": lambda: FastAPIWebsocketParams(
        audio_in_enabled=True,
        audio_out_enabled=True,
        vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=0.6)),
    ),
}

# ---------------------------------------------------------------------------
# Fallback prompt — used only when agent has no system_prompt_override
# and no script assigned. Agents should always have a script configured.
# ---------------------------------------------------------------------------

_FALLBACK_PROMPT = (
    "You are a polite AI assistant. "
    "No script has been configured for this agent yet. "
    "Greet the caller warmly, apologize that the service is not yet set up, "
    "and politely ask them to call back later. "
    "Then say goodbye and call end_call."
)

# ---------------------------------------------------------------------------
# Voice IDs per language — loaded from environment variables
# ---------------------------------------------------------------------------

# Urdu voices (4 style variants available)
VOICE_URDU_DEFAULT  = os.getenv("VOICE_URDU_DEFAULT",  "v_8eelc901")
VOICE_URDU_GEN_Z    = os.getenv("VOICE_URDU_GEN_Z",    "v_kwmp7zxt")
VOICE_URDU_DADA_JEE = os.getenv("VOICE_URDU_DADA_JEE", "v_yypgzenx")
VOICE_URDU_NEWS     = os.getenv("VOICE_URDU_NEWS",     "v_30s70t3a")

# Regional language voices
VOICE_SINDHI  = os.getenv("VOICE_SINDHI",  "v_sd0kl3m9")
VOICE_BALOCHI = os.getenv("VOICE_BALOCHI", "v_bl1de2f7")
VOICE_ENGLISH = os.getenv("VOICE_ENGLISH", "v_8eelc901")

# Maps detected language code → TTS voice ID
LANGUAGE_VOICE_MAP: dict[str, str] = {
    "en":  VOICE_ENGLISH,
    "ur":  VOICE_URDU_DEFAULT,
    "sd":  VOICE_SINDHI,
    "bal": VOICE_BALOCHI,
}

# Maps detected language code → Whisper language code for STT.
# OpenAI Whisper API rejects "sd" (Sindhi) with 400 and the pipecat
# OpenAISTTService asserts language is not None, so Sindhi falls back to "ur".
LANGUAGE_WHISPER_MAP: dict[str, str] = {
    "en":  "en",
    "ur":  "ur",
    "sd":  "ur",   # Whisper rejects "sd" with 400; Sindhi shares Nastaliq script with Urdu
    "bal": "ur",   # Balochi not in Whisper — Urdu is closest script match
}

# When False, Sindhi/Balochi voice switching is disabled — both fall back to the
# active Urdu streaming voice, avoiding the non-streaming HTTP+MP3-decode path.
# Set ENABLE_REGIONAL_TTS=false in .env to reduce latency at the cost of accent.
_REGIONAL_TTS_ENABLED: bool = os.getenv("ENABLE_REGIONAL_TTS", "true").lower() != "false"


def _detect_lang(text: str) -> str:
    """Detect language from transcribed text via Unicode character analysis.

    Pipecat's TranscriptionFrame.language is not reliably populated by the
    OpenAI STT service, so we inspect the actual transcript characters.

    Returns one of: "en", "ur", "sd", "bal"
    Balochi ("bal") is returned only on an explicit request word, since it
    shares the Perso-Arabic script with Urdu and cannot be told apart by chars.
    Bengali and Devanagari are treated as Urdu — Whisper hallucinates these
    scripts when processing noisy Pakistani audio.
    """
    if not text.strip():
        return "ur"

    alpha_chars = [c for c in text if c.isalpha()]
    if not alpha_chars:
        return "ur"

    # Whisper hallucination guard: Bengali (U+0980–U+09FF) and
    # Devanagari/Hindi (U+0900–U+097F) never appear in Pakistani speech —
    # fall back to Urdu so the wrong voice is not triggered.
    non_ascii_alpha = [c for c in alpha_chars if ord(c) >= 128]
    if non_ascii_alpha:
        bengali_or_devanagari = sum(
            1 for c in non_ascii_alpha if 0x0900 <= ord(c) <= 0x09FF
        )
        if bengali_or_devanagari / len(non_ascii_alpha) > 0.4:
            logger.debug(f"Whisper hallucination detected (Bengali/Devanagari) — treating as Urdu: {text[:40]!r}")
            return "ur"

    ascii_alpha = sum(1 for c in alpha_chars if ord(c) < 128)
    if ascii_alpha / len(alpha_chars) > 0.6:
        return "en"

    # Balochi: shares the Perso-Arabic script with Urdu, so reliable character-
    # level detection isn't possible. Switch only on an explicit request word —
    # otherwise an Urdu caller would be wrongly flipped to the Balochi voice.
    BALOCHI_WORDS = {"بلوچی", "بلوچی", "بلوچ", "balochi", "balochistan"}
    words = set(text.split())
    if len(words & BALOCHI_WORDS) >= 1:
        return "bal"

    # Sindhi-specific Unicode characters (ٻ ڀ ٺ ٽ ٿ ڄ ڃ ڇ ڊ ڌ ڍ ڎ ڏ ڙ ڦ ڱ ڳ)
    SINDHI_CHARS = set("ٻڀٺٽٿڄڃڇڊڌڍڎڏڙڦڱڳ")
    if any(c in SINDHI_CHARS for c in text):
        return "sd"

    # Common Sindhi words that use standard Arabic script (no unique chars).
    SINDHI_WORDS = {
        "منجو", "توهان", "توهانجو", "آهي", "ڇا", "آهيان", "ڪريو",
        "ڪيئن", "ڪيترو", "ڪٿي", "ڪڏهن", "ڪير", "ڪهڙو", "ڪهڙي",
        "سڃاڻپ", "مٿان", "هيٺان", "اسانجو",
        "وٺڻ", "ڏيڻ", "سگهان", "ٿو", "ٿي", "ٿا", "هئو",
        "جاءِ", "قسطون", "بجٽ",
        # Explicit Sindhi switch request in Urdu text
        "سندھی", "سنڌي", "sindhi",
    }
    words = set(text.split())
    if len(words & SINDHI_WORDS) >= 1:
        return "sd"

    # Default → Urdu (also covers Balochi and Pashto, which share the same Arabic script)
    return "ur"


# Whisper outputs these phrases when it hears silence or background noise.
_WHISPER_HALLUCINATIONS: frozenset[str] = frozenset({
    "thank you", "thanks", "thank you for watching", "thanks for watching",
    "good ideas are born", "you needle deer", "please subscribe",
    "like and subscribe", "see you next time", "don't forget to subscribe",
    "hmm", "um", "uh", "oh", "ah",
})


class STTNoiseFilter(FrameProcessor):
    """Drops TranscriptionFrames that are Whisper noise or hallucinations.

    Three checks (any match → frame is silently dropped):
    1. Text shorter than MIN_CHARS — single-char presses, mic pops, etc.
    2. Known Whisper hallucination phrases — phrases Whisper emits on silence.
    3. Bengali / Devanagari dominant text — Whisper misreads Pakistani audio
       as these scripts; they never occur in real Pakistani caller speech.
    """

    MIN_CHARS = 3

    async def process_frame(self, frame: Frame, direction: FrameDirection) -> None:
        await super().process_frame(frame, direction)

        if isinstance(frame, TranscriptionFrame) and direction == FrameDirection.DOWNSTREAM:
            text = (frame.text or "").strip()

            if len(text) < self.MIN_CHARS:
                logger.debug(f"STTNoiseFilter: dropped short transcription: {text!r}")
                return

            normalized = text.lower().rstrip(" .!?,")
            if normalized in _WHISPER_HALLUCINATIONS:
                logger.debug(f"STTNoiseFilter: dropped hallucination: {text!r}")
                return

            non_ascii = [c for c in text if ord(c) >= 128]
            if non_ascii:
                bd_count = sum(1 for c in non_ascii if 0x0900 <= ord(c) <= 0x09FF)
                if bd_count / len(non_ascii) > 0.4:
                    logger.debug(f"STTNoiseFilter: dropped Bengali/Devanagari: {text!r}")
                    return

        await self.push_frame(frame, direction)


class LanguageVoiceSwitcher(FrameProcessor):
    """Watches every TranscriptionFrame and switches:
      - TTS voice to match detected language
      - STT language so the *next* Whisper call uses the right language model

    Placed between noise_filter and user_aggregator in the pipeline.
    `force_language()` can also be called externally (e.g. from
    TTSLanguageMonitor) to switch proactively when the BOT language changes."""

    def __init__(self, tts: UpliftStreamingTTSService, stt: OpenAISTTService, initial_lang: str = "ur", **kwargs):
        super().__init__(**kwargs)
        self._tts = tts
        self._stt = stt
        self._active_lang: str = initial_lang
        self._voice_map: dict[str, str] = LANGUAGE_VOICE_MAP

    def set_voice_map(self, voice_map: dict[str, str]) -> None:
        """Override default voice map with agent-specific voices."""
        self._voice_map = voice_map

    async def force_language(self, lang: str) -> None:
        """Proactively switch language without waiting for a user TranscriptionFrame."""
        if not _REGIONAL_TTS_ENABLED and lang in ("sd", "bal"):
            lang = "ur"
        if lang == self._active_lang:
            return
        self._active_lang = lang
        voice = self._voice_map.get(lang, VOICE_URDU_DEFAULT)
        await self._tts.set_voice_id(voice)
        whisper_lang = LANGUAGE_WHISPER_MAP.get(lang, "ur")
        self._stt._settings.language = whisper_lang
        logger.info(f"Language force-switched to {lang} — voice: {voice}, STT: {whisper_lang!r}")

    async def process_frame(self, frame: Frame, direction: FrameDirection) -> None:
        await super().process_frame(frame, direction)

        if isinstance(frame, TranscriptionFrame) and direction == FrameDirection.DOWNSTREAM:
            lang = _detect_lang(frame.text)
            if not _REGIONAL_TTS_ENABLED and lang in ("sd", "bal"):
                lang = "ur"
            if lang != self._active_lang:
                # Never switch back to Urdu based on user speech alone — the user
                # may ask a question in neutral Arabic script while the conversation
                # is still in Sindhi. Back-to-Urdu is handled by PreTTSLanguageSwitcher
                # which watches the bot's own response language.
                if lang == "ur" and self._active_lang != "ur":
                    logger.debug(f"User speech detected as {lang} but staying on {self._active_lang} — waiting for bot response to confirm switch")
                else:
                    self._active_lang = lang
                    voice = self._voice_map.get(lang, VOICE_URDU_DEFAULT)
                    await self._tts.set_voice_id(voice)
                    whisper_lang = LANGUAGE_WHISPER_MAP.get(lang, "ur")
                    self._stt._settings.language = whisper_lang
                    logger.info(f"Language detected: {lang} — voice: {voice}, STT: {whisper_lang!r}")

        await self.push_frame(frame, direction)


class PreTTSLanguageSwitcher(FrameProcessor):
    """Pipeline processor sitting between LLM and TTS.

    Intercepts TTSTextFrame before it reaches the TTS service and switches
    the TTS voice + STT language if the text is in a different language.
    This runs synchronously in the pipeline so the voice is set BEFORE
    TTS starts generating audio — fixing the race condition where
    TTSLanguageMonitor (an observer) fired 2+ seconds after TTS had started.
    """

    def __init__(self, switcher: LanguageVoiceSwitcher, **kwargs):
        super().__init__(**kwargs)
        self._switcher = switcher

    async def process_frame(self, frame: Frame, direction: FrameDirection) -> None:
        await super().process_frame(frame, direction)

        if isinstance(frame, TTSTextFrame) and direction == FrameDirection.DOWNSTREAM:
            lang = _detect_lang(frame.text or "")
            # Balochi shares the Urdu script, so a Balochi reply is detected as
            # "ur". Don't let that flip us out of Balochi mid-conversation — once
            # the caller has explicitly switched to Balochi, stay until they ask
            # for another language (which carries its own detectable signal).
            if lang == "ur" and self._switcher._active_lang == "bal":
                pass
            elif lang != self._switcher._active_lang:
                await self._switcher.force_language(lang)

        await self.push_frame(frame, direction)


# ---------------------------------------------------------------------------
# end_call tool — lets the LLM terminate the call gracefully
# ---------------------------------------------------------------------------

END_CALL_TOOLS = ToolsSchema(
    standard_tools=[
        FunctionSchema(
            name="end_call",
            description=(
                "کال ختم کریں۔ استعمال کریں جب: "
                "(1) صارف خدا حافظ، اللہ حافظ، bye، goodbye یا کوئی الوداعی لفظ کہے۔ "
                "(2) صارف کا کوئی سوال نہ ہو اور وہ کال ختم کرنا چاہے۔"
            ),
            properties={},
            required=[],
        ),
        FunctionSchema(
            name="check_caller_history",
            description=(
                "کالر کی پچھلی calls کا محفوظ شدہ ریکارڈ (extracted data) ڈیٹابیس میں تلاش کریں۔ "
                "جب کالر اپنی کسی بھی پچھلی بات چیت کے بارے میں پوچھے — مثلاً 'میں نے پہلے کیا بتایا تھا؟'، "
                "'کیا میری appointment/booking/order/شکایت پہلے درج ہوئی تھی؟'، "
                "'میرا پچھلا ریکارڈ کیا ہے؟'، یا کسی فون نمبر کا ریکارڈ پوچھے — تو یہ function call کریں۔ "
                "اگر کالر کوئی فون نمبر بتائے تو وہ phone_number میں بھیجیں، ورنہ خالی چھوڑ دیں "
                "(خود کالر کا نمبر استعمال ہوگا)۔ "
                "function call سے پہلے کالر کو ایک مختصر جملہ کہیں کہ 'ایک منٹ، میں check کرتا ہوں'۔"
            ),
            properties={
                "phone_number": {
                    "type": "string",
                    "description": (
                        "اختیاری — وہ فون نمبر جس کا ریکارڈ دیکھنا ہے "
                        "(مثلاً 03244283400 یا +923244283400)۔ "
                        "اگر کالر نمبر نہ بتائے تو یہ خالی چھوڑ دیں۔"
                    ),
                },
            },
            required=[],
        ),
    ]
)

# ---------------------------------------------------------------------------
# Per-agent RAG cache — async-safe with per-agent locks
# ---------------------------------------------------------------------------

_rag_cache: dict[str, ScriptRAG] = {}
_rag_locks: dict[str, asyncio.Lock] = {}


async def _get_agent_rag(agent: dict) -> ScriptRAG | None:
    """Build and cache the RAG for an agent's DB script. Returns None if no script.

    Uses a per-agent asyncio.Lock so concurrent calls for the same agent
    never trigger duplicate OpenAI embedding API requests.
    """
    agent_id = agent.get("id", "")
    if not agent_id:
        return None

    # Fast path — already cached
    if agent_id in _rag_cache:
        return _rag_cache[agent_id]

    # Lazy-create a lock per agent (setdefault is atomic under the GIL)
    _rag_locks.setdefault(agent_id, asyncio.Lock())
    async with _rag_locks[agent_id]:
        # Re-check inside lock (another coroutine may have built it while we waited)
        if agent_id in _rag_cache:
            return _rag_cache[agent_id]

        script_data = agent.get("scripts") or {}
        content = script_data.get("content", "")
        if not content:
            logger.warning(f"Agent '{agent.get('name')}' has no script content — RAG disabled.")
            return None

        logger.info(f"Building RAG for agent '{agent.get('name')}' from DB script…")
        rag = await ScriptRAG.from_content(content, openai_api_key=os.getenv("OPENAI_API_KEY", ""))
        _rag_cache[agent_id] = rag
        logger.info(f"Agent RAG ready — {rag.chunk_count} chunks.")
        return rag


# ---------------------------------------------------------------------------
# Caller history context builder
# ---------------------------------------------------------------------------

def _build_caller_history_context(caller_history: list) -> str:
    """Convert caller history list into a Urdu context string for the LLM.

    Always returns a non-empty string so the agent knows it has access to
    caller history — even when the list is empty (first-time caller).
    """
    lines = ["=== اس کالر کی پچھلی کالوں کا ریکارڈ ==="]

    if not caller_history:
        lines.append("اس نمبر کی کوئی پچھلی call ریکارڈ میں نہیں ملی۔")
    else:
        for i, call in enumerate(caller_history, 1):
            started = call.get("started_at", "")
            if started:
                try:
                    dt = datetime.fromisoformat(started.replace("Z", "+00:00"))
                    started = dt.astimezone(timezone.utc).strftime("%Y-%m-%d")
                except Exception:
                    started = str(started)[:10]

            ed = call.get("extracted_data") or {}
            if ed:
                fields = "، ".join(f"{k}: {v}" for k, v in ed.items() if v)
                lines.append(f"کال {i} ({started}): {fields}")
            else:
                lines.append(f"کال {i} ({started}): تفصیل دستیاب نہیں")

    lines.append(
        "ہدایت: اگر کالر اپنی کسی بھی پچھلی بات چیت، معلومات، یا ریکارڈ کے بارے میں پوچھے — "
        "تو اوپر دیے گئے ریکارڈ سے جواب دیں۔ "
        "جو معلومات ریکارڈ میں ہو وہی بتائیں، جو نہ ہو اسے صاف کہیں کہ ریکارڈ میں نہیں ملی۔ "
        "زیادہ تفصیل یا کسی مخصوص نمبر کے لیے check_caller_history استعمال کریں۔ "
        "جو چیزیں پہلے بتائی جا چکی ہیں انہیں دوبارہ نہ پوچھیں۔"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bot pipeline
# ---------------------------------------------------------------------------

async def run_bot(
    transport: BaseTransport,
    runner_args: RunnerArguments,
    hangup_callback=None,
    is_outbound: bool = False,
    agent: dict | None = None,
    db_call_id: str | None = None,
    call_control_id: str | None = None,
    caller_history: list | None = None,
    caller_phone: str | None = None,
):
    logger.info(f"Starting bot — agent={agent.get('name') if agent else 'none'}")

    # RAG: build in background so pipeline setup runs in parallel.
    # If RAG is already cached this is instant; if not, it builds while
    # the pipeline initialises and the greeting TTS plays (~1-2s window).
    rag_task = asyncio.create_task(_get_agent_rag(agent)) if agent else None

    # Extraction target fields from the agent's script — drives the generic,
    # domain-agnostic "what to collect" reminder injected each turn.
    script_cfg = (agent.get("scripts") or {}) if agent else {}
    extraction_fields = script_cfg.get("extraction_fields") or []

    # Voice map and system prompt — always from agent config
    default_lang = (agent.get("default_language") or "ur") if agent else "ur"

    if agent:
        voice_map: dict[str, str] = {
            "en":  agent.get("voice_english", VOICE_ENGLISH),
            "ur":  agent.get("voice_urdu",    get_default_urdu_voice()),
            "sd":  agent.get("voice_sindhi",  VOICE_SINDHI),
            "bal": agent.get("voice_balochi", VOICE_BALOCHI),
        }
        system_prompt = agent.get("system_prompt_override") or _FALLBACK_PROMPT
    else:
        voice_map = {
            "en":  VOICE_ENGLISH,
            "ur":  get_default_urdu_voice(),
            "sd":  VOICE_SINDHI,
            "bal": VOICE_BALOCHI,
        }
        system_prompt = _FALLBACK_PROMPT

    initial_voice = voice_map.get(default_lang, voice_map["ur"])

    # Mutable holder so the end_call handler can cancel the task after it's created
    task_holder: list = [None]

    async with aiohttp.ClientSession() as session:
        # Default STT language = Urdu so Whisper transcribes Pakistani callers correctly
        # from the very first turn (no cold-start auto-detect delay).
        # LanguageVoiceSwitcher still overrides this when Sindhi/Balochi is detected.
        stt = OpenAISTTService(
            api_key=os.getenv("OPENAI_API_KEY"),
            language=LANGUAGE_WHISPER_MAP.get(default_lang, "ur"),
        )

        # Streaming TTS: default Urdu voice — switched at runtime by LanguageVoiceSwitcher
        tts = UpliftStreamingTTSService(
            api_key=os.getenv("UPLIFT_API_KEY"),
            voice_id=initial_voice,
            aiohttp_session=session,
        )

        llm = OpenAILLMService(
            api_key=os.getenv("OPENAI_API_KEY"),
            model="gpt-4o",
        )

        noise_filter = STTNoiseFilter()
        lang_switcher = LanguageVoiceSwitcher(tts=tts, stt=stt, initial_lang=default_lang)
        lang_switcher.set_voice_map(voice_map)
        pre_tts_switcher = PreTTSLanguageSwitcher(switcher=lang_switcher)

        # end_call handler: give TTS ~3 s to speak the farewell, then hang up
        async def end_call_handler(params: FunctionCallParams):
            logger.info("end_call tool triggered — ending call after farewell TTS")
            await params.result_callback({"status": "ending"})
            await asyncio.sleep(5)
            if hangup_callback is not None:
                await hangup_callback()
            if task_holder[0] is not None:
                await task_holder[0].cancel()

        async def check_caller_history_handler(params: FunctionCallParams):
            from app.core.database import search_caller_records
            from app.core.phone import normalize_phone

            # Speak an immediate filler so the caller isn't met with silence
            # while the DB lookup runs (modern pipecat pattern: filler in handler).
            await params.llm.push_frame(TTSSpeakFrame("ایک منٹ، میں ریکارڈ check کرتا ہوں۔"))

            # Prefer a number the caller spoke; otherwise use their own line.
            spoken = (params.arguments or {}).get("phone_number")
            phone = normalize_phone(spoken) or normalize_phone(caller_phone)
            agent_id = agent.get("id") if agent else None

            if not phone:
                await params.result_callback(
                    {"found": False, "message": "فون نمبر معلوم نہیں — کالر سے نمبر پوچھیں۔"}
                )
                return

            records = await search_caller_records(phone, agent_id=agent_id)
            logger.info(f"check_caller_history: phone={phone} records={len(records)}")

            if not records:
                await params.result_callback({
                    "found": False,
                    "phone": phone,
                    "message": "اس نمبر کا کوئی پچھلا ریکارڈ نہیں ملا۔",
                })
                return

            await params.result_callback({
                "found": True,
                "phone": phone,
                "record_count": len(records),
                "records": records,
            })

        llm.register_function("end_call", end_call_handler)
        llm.register_function("check_caller_history", check_caller_history_handler)

        messages = [{"role": "system", "content": system_prompt}]
        history_ctx = _build_caller_history_context(caller_history or [])
        messages.append({"role": "system", "content": history_ctx})
        logger.info(f"Caller history injected: {len(caller_history or [])} previous call(s)")
        messages.append({"role": "system", "content": (
            "NUMBER RULE — strictly follow this every time you speak a number:\n"
            "1. Phone numbers: say every digit in English words — "
            "e.g. 03244284000 → 'zero three two four four two eight four zero zero zero'.\n"
            "2. Amounts/fees: say in English words — "
            "e.g. 1500 → 'fifteen hundred', 5000 → 'five thousand', 500 → 'five hundred'.\n"
            "3. Dates/times: say in English — "
            "e.g. 'tomorrow', 'six pm', 'Wednesday', 'next Friday'.\n"
            "4. Any other number: say in English digits or words, never in Urdu.\n"
            "This rule overrides everything else."
        )})
        context = LLMContext(messages, tools=END_CALL_TOOLS)
        user_aggregator, assistant_aggregator = LLMContextAggregatorPair(context)

        rtvi = RTVIProcessor()
        call_id = uuid.uuid4().hex[:8]
        convo_logger = ConversationLogger(
            call_id=call_id,
            db_call_id=db_call_id,
            call_control_id=call_control_id,
        )

        # Resolve RAG (may already be done if cache hit or build finished during setup)
        rag: ScriptRAG | None = (await rag_task) if rag_task is not None else None

        # Build pipeline — RAGContextInjector only added when agent has a script
        pipeline_stages = [
            transport.input(),
            rtvi,
            stt,
            noise_filter,
            lang_switcher,
            user_aggregator,
        ]
        if rag is not None:
            pipeline_stages.append(RAGContextInjector(rag=rag, top_k=3, extraction_fields=extraction_fields))
        pipeline_stages.extend([
            llm,
            pre_tts_switcher,
            tts,
            transport.output(),
            assistant_aggregator,
        ])

        pipeline = Pipeline(pipeline_stages)

        task = PipelineTask(
            pipeline,
            params=PipelineParams(
                enable_metrics=True,
                enable_usage_metrics=True,
            ),
            observers=[
                RTVIObserver(rtvi),
                convo_logger,
                DebugLogObserver(
                    frame_types={
                        TTSTextFrame: (BaseOutputTransport, FrameEndpoint.SOURCE),
                    }
                ),
            ],
            idle_timeout_secs=runner_args.pipeline_idle_timeout_secs,
        )
        task_holder[0] = task

        @transport.event_handler("on_client_connected")
        async def on_client_connected(transport, client):
            logger.info(f"Client connected (outbound={is_outbound})")
            if is_outbound:
                # Outbound: direct TTS greeting — no LLM delay.
                agent_name = (agent.get("name") or "") if agent else ""
                _OUT_GREETINGS = {
                    "ur":  f"السلام علیکم! {agent_name} کی طرف سے آپ کو کال کی جا رہی ہے۔ کیا آپ کے پاس چند لمحے ہیں؟",
                    "en":  f"Hello! This is {agent_name} calling. Do you have a moment to talk?",
                    "sd":  f"السلام علیکم! {agent_name} طرفان توهان کي ڪال ٿي رهي آهي۔ ڇا توهان وٽ ٿوري دير آهي؟",
                    "bal": f"السلام علیکم! {agent_name} کی طرف سے آپ کو کال کی جا رہی ہے۔ کیا آپ کے پاس چند لمحے ہیں؟",
                }
                out_greeting = _OUT_GREETINGS.get(default_lang, _OUT_GREETINGS["ur"])
                messages.append({"role": "assistant", "content": out_greeting})
                await task.queue_frames([TTSSpeakFrame(out_greeting)])
            else:
                # Inbound: play greeting directly via TTS — skips LLM TTFT entirely.
                # Reduces first-response delay from ~8s to ~1s.
                # LLM takes over from turn 2 with full context already loaded.
                _GREETINGS = {
                    "ur":  "السلام علیکم! آپ کا شکریہ کال کرنے کا۔ میں آپ کی کیا مدد کر سکتا ہوں؟",
                    "en":  "Hello! Thank you for calling. How can I help you today?",
                    "sd":  "السلام علیکم! توهان جي ڪال جو مهرباني۔ مان توهان جي ڪيئن مدد ڪري سگهان ٿو؟",
                    "bal": "السلام علیکم! آپ کا شکریہ کال کرنے کا۔ میں آپ کی کیا مدد کر سکتا ہوں؟",
                }
                greeting_text = _GREETINGS.get(default_lang, _GREETINGS["ur"])
                # Add to context as assistant message so LLM doesn't re-greet
                messages.append({"role": "assistant", "content": greeting_text})
                await task.queue_frames([TTSSpeakFrame(greeting_text)])

        @transport.event_handler("on_client_disconnected")
        async def on_client_disconnected(transport, client):
            logger.info("Client disconnected")
            if hangup_callback is not None:
                await hangup_callback()
            await task.cancel()

        runner = PipelineRunner(handle_sigint=runner_args.handle_sigint)
        try:
            await runner.run(task)
        finally:
            # Guarantee the final turns are persisted before this call's pipeline
            # tears down — post-call extraction reads them from the DB.
            await convo_logger.flush()


async def bot(
    runner_args: RunnerArguments,
    hangup_callback=None,
    is_outbound: bool = False,
    agent: dict | None = None,
    db_call_id: str | None = None,
    call_control_id: str | None = None,
    caller_history: list | None = None,
    caller_phone: str | None = None,
):
    """Main bot entry point compatible with Pipecat Cloud."""
    transport = await create_transport(runner_args, transport_params)
    await run_bot(
        transport,
        runner_args,
        hangup_callback=hangup_callback,
        is_outbound=is_outbound,
        agent=agent,
        db_call_id=db_call_id,
        call_control_id=call_control_id,
        caller_history=caller_history,
        caller_phone=caller_phone,
    )


if __name__ == "__main__":
    from pipecat.runner.run import main
    main()
