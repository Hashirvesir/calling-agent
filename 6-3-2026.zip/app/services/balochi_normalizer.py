
"""Balochi text normalization for TTS phoneme stability.

WHY BALOCHI UNICODE BREAKS PHONEME PARSING
==========================================
Balochi is written in the Perso-Arabic (Nastaliq) script — the same family as
Urdu and Sindhi. The Uplift TTS phoneme parser operates at the Unicode
code-point level, so Arabic combining/diacritical marks (which visually attach
to the preceding consonant) are seen by the parser as standalone characters and
each one emits its own phoneme. The result is letter-by-letter / spelling-out
artifacts instead of smooth words.

This mirrors the Sindhi normalizer (`sindhi_normalizer.py`) because the breakage
is a script-level problem, not a language-specific one: any Perso-Arabic text
with tashkeel triggers it. Stripping the marks gives the parser whole word units.

UNICODE RANGES STRIPPED
=======================
  U+064B–U+065F  Arabic tashkeel (harakat): fathatan, kasratan, dammatan,
                 fatha (َ), kasra (ِ), damma (ُ), shadda (ّ), sukun (ْ), etc.
  U+0610–U+061A  Arabic honorific / Quranic signs (ؐ ؑ ؒ ؓ ؔ etc.)
  U+0670         Arabic letter superscript alef (dagger alef)
  U+06D6–U+06ED  Arabic small high letters (Quranic annotation marks)
  U+200B         Zero width space (splits word at byte level)
  U+200C         Zero width non-joiner
  U+200D         Zero width joiner
  U+FEFF         BOM / zero width no-break space
"""

import re

_TASHKEEL = re.compile(r'[ً-ٟ]')
_ARABIC_SIGNS = re.compile(r'[ؐ-ؚ]')
_DAGGER_ALEF = re.compile(r'ٰ')
_QURANIC_SMALL = re.compile(r'[ۖ-ۭ]')
_ZERO_WIDTH = re.compile(r'[​-‍﻿]')
_HAMZA_HARAKAT = re.compile(r'ء[ً-ٟ]')
_EASTERN_DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')
_ARABIC_PUNCT = str.maketrans({
    '۔': '.',
    '؟': '?',
    '،': ',',
    '؛': ';',
})
_MULTI_SPACE = re.compile(r' {2,}')


def normalize_balochi(raw: str) -> str:
    """Clean Balochi text for stable TTS phoneme parsing."""
    if not raw:
        return raw
    text = raw
    text = _HAMZA_HARAKAT.sub('ء', text)
    text = _TASHKEEL.sub('', text)
    text = _ARABIC_SIGNS.sub('', text)
    text = _DAGGER_ALEF.sub('', text)
    text = _QURANIC_SMALL.sub('', text)
    text = _ZERO_WIDTH.sub('', text)
    text = text.translate(_EASTERN_DIGITS)
    text = text.translate(_ARABIC_PUNCT)
    text = _MULTI_SPACE.sub(' ', text)
    text = text.strip()
    return text
