"""Telnyx Programmable Voice webhooks + WebSocket media stream.

Telnyx endpoints:
    POST /webhook    — Telnyx Call Control events
    WS   /ws         — Telnyx media stream → pipecat pipeline
    POST /dial       — Initiate outbound call

All call data (events, call records, transcripts) is saved to Supabase.
Agent lookup by Telnyx number routes each call to the correct script/voice.
"""

import asyncio
import base64
import json
import os
import re
import time
from datetime import datetime, timezone
from urllib.parse import quote, unquote

import aiohttp
from fastapi import APIRouter, Form, HTTPException, Request, WebSocket
from fastapi.responses import JSONResponse, RedirectResponse
from loguru import logger

from pipecat.runner.types import WebSocketRunnerArguments

from app.services.bot import bot
from app.core.database import (
    create_call, update_call, end_call, get_call_id_by_ccid,
    log_event, upload_recording, get_agent_by_number,
    get_call_agent_and_script, get_caller_history,
)
from app.core.config import settings

router = APIRouter(tags=["telnyx"])

TELNYX_API = "https://api.telnyx.com/v2"
_WEBHOOK_TOLERANCE_SECS = 300  # reject webhooks older than 5 minutes

# ---------------------------------------------------------------------------
# Webhook signature verification (Ed25519)
# ---------------------------------------------------------------------------

def _verify_webhook_signature(body: bytes, timestamp: str, signature_b64: str) -> bool:
    """Verify Telnyx webhook using Ed25519. Returns True if valid or key not configured."""
    pub_key_b64 = settings.telnyx_webhook_public_key
    if not pub_key_b64:
        logger.warning("TELNYX_WEBHOOK_PUBLIC_KEY not set — skipping signature verification")
        return True
    try:
        # Replay attack guard
        ts = int(timestamp)
        if abs(time.time() - ts) > _WEBHOOK_TOLERANCE_SECS:
            logger.warning(f"Webhook timestamp too old: {ts}")
            return False

        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature

        pub_bytes = base64.b64decode(pub_key_b64)
        public_key = Ed25519PublicKey.from_public_bytes(pub_bytes)
        message = f"{timestamp}|".encode() + body
        public_key.verify(base64.b64decode(signature_b64), message)
        return True
    except Exception as exc:
        logger.warning(f"Webhook signature invalid: {exc}")
        return False


# ---------------------------------------------------------------------------
# Persistent aiohttp session for Telnyx API calls
# ---------------------------------------------------------------------------

_telnyx_session: aiohttp.ClientSession | None = None


async def _get_telnyx_session() -> aiohttp.ClientSession:
    global _telnyx_session
    if _telnyx_session is None or _telnyx_session.closed:
        _telnyx_session = aiohttp.ClientSession()
    return _telnyx_session

# ---------------------------------------------------------------------------
# Post-call extraction
# ---------------------------------------------------------------------------

# Tracks calls whose extraction has already been triggered, so the same call
# ending via multiple events (call.hangup + streaming.stopped) only extracts once.
_extraction_done: set[str] = set()


async def _trigger_extraction_after_call(call_control_id: str) -> None:
    """Auto-run extraction after a call ends. Fire-and-forget safe.

    Waits 5 s so all ConversationLogger DB writes finish before reading turns.
    Skips silently if the agent's script has no extraction_fields.
    De-duplicated per call_control_id — safe to call from every end-of-call event.
    """
    # Guard runs synchronously (before any await) so two concurrent triggers
    # for the same call can never both pass.
    if not call_control_id or call_control_id in _extraction_done:
        return
    _extraction_done.add(call_control_id)
    # Bound memory on long-running servers — the set only needs a short window.
    if len(_extraction_done) > 1000:
        _extraction_done.clear()
        _extraction_done.add(call_control_id)

    await asyncio.sleep(5)
    try:
        data = await get_call_agent_and_script(call_control_id)
        if not data:
            logger.debug(f"Extraction skipped — no call/agent data for {call_control_id[:14]}")
            return

        call_id = data.get("call_id")
        agent_name = data.get("agent_name", "unknown_agent")
        extraction_fields = data.get("extraction_fields") or []

        if not call_id or not extraction_fields:
            logger.info(
                f"Extraction skipped — "
                f"{'no call_id' if not call_id else 'no extraction_fields defined'} "
                f"for {call_control_id[:14]}"
            )
            return

        from app.extraction.models import ExtractionSchema
        from app.extraction.service import get_extraction_service

        schema = ExtractionSchema.from_raw(agent_name, extraction_fields)
        service = get_extraction_service()
        result = await service.extract(schema=schema, call_id=call_id)

        logger.info(
            f"Auto-extraction done: agent={agent_name} call_id={call_id} "
            f"confidence={result.confidence} missing={result.missing_fields}"
        )
    except Exception as exc:
        logger.error(f"Auto-extraction failed for {call_control_id[:14]}: {exc}")
_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")

# Tracks active WebSocket sessions to prevent duplicate bots per call
_active_ws: set[str] = set()

# Outbound call registry: ccid → (from_number, timestamp)
# Used as fallback when Telnyx omits/misreports direction in call.answered
_outbound_registry: dict[str, tuple[str, float]] = {}
_OUTBOUND_TTL = 120  # seconds


# ---------------------------------------------------------------------------
# Telnyx helpers
# ---------------------------------------------------------------------------

async def _telnyx_post(path: str, payload: dict) -> tuple[int, dict | str]:
    url = f"{TELNYX_API}{path}"
    headers = {
        "Authorization": f"Bearer {settings.telnyx_api_key}",
        "Content-Type": "application/json",
    }
    session = await _get_telnyx_session()
    async with session.post(url, json=payload, headers=headers) as resp:
        text = await resp.text()
        try:
            body = json.loads(text)
        except json.JSONDecodeError:
            body = text
        if resp.status >= 300:
            if resp.status == 422:
                logger.debug(f"Telnyx POST {path} 422 (call already ended): {text[:80]}")
            else:
                logger.error(f"Telnyx POST {path} failed [{resp.status}]: {text}")
        else:
            logger.info(f"Telnyx POST {path} ok: {text[:120]}")
        return resp.status, body


async def _telnyx_action(call_control_id: str, action: str, payload: dict | None = None):
    return await _telnyx_post(f"/calls/{call_control_id}/actions/{action}", payload or {})


async def _start_recording(call_control_id: str, delay: float = 2.0) -> None:
    await asyncio.sleep(delay)
    status, _ = await _telnyx_action(
        call_control_id, "record_start",
        {"format": "mp3", "channels": "single", "play_beep": False},
    )
    if status < 300:
        logger.info(f"Recording started for {call_control_id[:14]}…")
    else:
        logger.warning(f"record_start failed [{status}] for {call_control_id[:14]}…")


async def _download_and_store_recording(call_control_id: str, url: str) -> None:
    """Download MP3 from Telnyx and upload to Supabase Storage."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    logger.error(f"Recording download failed [{resp.status}]: {url}")
                    return
                mp3_bytes = await resp.read()

        storage_path = await upload_recording(call_control_id, mp3_bytes)
        if storage_path:
            await update_call(call_control_id, recording_storage_path=storage_path)
            logger.info(f"Recording stored: {storage_path}")

    except Exception as exc:
        logger.error(f"Recording store error: {exc}")


# ---------------------------------------------------------------------------
# Webhook
# ---------------------------------------------------------------------------

@router.get("/webhook")
async def webhook_verify():
    return {"ok": True}


@router.post("/webhook")
async def webhook(request: Request):
    body = await request.body()

    # Signature verification
    sig   = request.headers.get("telnyx-signature-ed25519", "")
    ts    = request.headers.get("telnyx-timestamp", "")
    if sig and ts:
        if not _verify_webhook_signature(body, ts, sig):
            raise HTTPException(403, "Invalid webhook signature")

    data = json.loads(body)
    event = data.get("data", {})
    event_type = event.get("event_type")
    payload = event.get("payload", {})
    call_control_id = payload.get("call_control_id")
    direction = payload.get("direction")
    from_num = payload.get("from")
    to_num = payload.get("to")

    logger.info(f"Telnyx event: {event_type}")

    # Persist raw event to DB (fire-and-forget)
    asyncio.create_task(log_event(
        event_type=event_type,
        call_control_id=call_control_id,
        direction=direction,
        from_number=from_num,
        to_number=to_num,
        call_leg_id=payload.get("call_leg_id"),
        occurred_at=payload.get("occurred_at"),
        raw_payload=payload,
    ))

    if event_type == "call.initiated":
        if direction == "incoming":
            # Create call record in DB
            agent = await get_agent_by_number(to_num) if to_num else None
            agent_id = agent.get("id") if agent else None
            asyncio.create_task(create_call(
                call_control_id=call_control_id,
                direction="inbound",
                from_number=from_num,
                to_number=to_num,
                agent_id=agent_id,
            ))
            await _telnyx_action(call_control_id, "answer")

    elif event_type == "call.answered":
        if not settings.public_host:
            logger.error("PUBLIC_HOST env var not set — cannot start media stream")
            return {"ok": False, "error": "PUBLIC_HOST not configured"}
        asyncio.create_task(update_call(call_control_id, status="in_progress"))
        # Pass all call context as query params — eliminates deque race condition
        stream_url = (
            f"wss://{settings.public_host}/ws"
            f"?ccid={call_control_id}"
            f"&dir={direction or 'incoming'}"
            f"&from_num={quote(from_num or '')}"
            f"&to_num={quote(to_num or '')}"
        )
        logger.info(f"Starting stream: {stream_url[:80]}…")
        await _telnyx_action(
            call_control_id, "streaming_start",
            {
                "stream_url": stream_url,
                "stream_track": "inbound_track",
                "stream_bidirectional_mode": "rtp",
                "stream_bidirectional_codec": "PCMU",
            },
        )

    elif event_type == "streaming.failed":
        logger.error(f"streaming.failed payload: {payload}")
        if call_control_id:
            asyncio.create_task(end_call(call_control_id, final_status="stream_failed"))
            asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    elif event_type == "call.recording.saved":
        rec_urls = payload.get("recording_urls") or {}
        pub_urls = payload.get("public_recording_urls") or {}
        url = rec_urls.get("mp3") or pub_urls.get("mp3")
        if url and call_control_id:
            logger.info(f"Recording ready — downloading and storing")
            asyncio.create_task(_download_and_store_recording(call_control_id, url))

    elif event_type == "call.hangup":
        logger.info(f"Call ended (hangup): {call_control_id}")
        asyncio.create_task(end_call(call_control_id))
        asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    elif event_type == "streaming.stopped":
        logger.info(f"Stream stopped: {call_control_id}")
        asyncio.create_task(end_call(call_control_id))
        asyncio.create_task(_trigger_extraction_after_call(call_control_id))

    return {"ok": True}


# ---------------------------------------------------------------------------
# WebSocket (media stream)
# ---------------------------------------------------------------------------

@router.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()

    # FIX: read call context directly from URL query params — no deque, no race condition
    ccid           = websocket.query_params.get("ccid")
    call_direction = websocket.query_params.get("dir", "incoming")
    from_num       = unquote(websocket.query_params.get("from_num", "")) or None
    to_num         = unquote(websocket.query_params.get("to_num",  "")) or None

    if ccid:
        logger.info(f"WebSocket: ccid={ccid[:14]}… dir={call_direction}")
    else:
        logger.warning("WebSocket connected with no ccid in query params")

    is_outbound = call_direction == "outgoing"

    # Fallback: if direction is wrong/missing, check outbound registry by ccid
    now = time.time()
    if not is_outbound and ccid and ccid in _outbound_registry:
        reg_from_num, reg_ts = _outbound_registry.pop(ccid)
        if now - reg_ts < _OUTBOUND_TTL:
            is_outbound = True
            if not from_num:
                from_num = reg_from_num
            logger.info(f"Outbound detected via registry fallback: ccid={ccid[:14]}… from={reg_from_num}")

    # Expire stale outbound registry entries
    stale = [k for k, (_, ts) in _outbound_registry.items() if now - ts > _OUTBOUND_TTL]
    for k in stale:
        _outbound_registry.pop(k, None)

    # Prevent duplicate bot for the same call
    session_key = ccid or f"anon-{time.time()}"
    if session_key in _active_ws:
        logger.warning(f"Duplicate WebSocket for {session_key[:14]} — closing")
        await websocket.close(code=1008)
        return
    _active_ws.add(session_key)

    # Agent lookup: inbound → to_num is agent's number; outbound → from_num is agent's number
    lookup_number = from_num if is_outbound else to_num
    agent = None
    if lookup_number:
        agent = await get_agent_by_number(lookup_number)
        if agent:
            logger.info(f"Agent matched: {agent.get('name')} (number={lookup_number})")
        else:
            logger.info(f"No agent found for number {lookup_number}")

    # Caller history: inbound → from_num is caller; outbound → to_num is caller
    caller_phone = from_num if not is_outbound else to_num
    caller_history: list = []
    if caller_phone:
        agent_id_for_history = agent.get("id") if agent else None
        caller_history = await get_caller_history(caller_phone, agent_id=agent_id_for_history)
        if caller_history:
            logger.info(f"Caller history: {len(caller_history)} previous call(s) for {caller_phone}")

    # Resolve DB call UUID
    db_call_id = await get_call_id_by_ccid(ccid) if ccid else None

    # Start recording (2 s delay for RTP stream to establish)
    if ccid:
        asyncio.create_task(_start_recording(ccid))

    _hung_up = False

    async def hangup_callback():
        nonlocal _hung_up
        if ccid and not _hung_up:
            _hung_up = True
            logger.info(f"Sending Telnyx hangup for {ccid[:14]}…")
            await _telnyx_action(ccid, "hangup")

    runner_args = WebSocketRunnerArguments(websocket=websocket)
    runner_args.handle_sigint = False
    runner_args.pipeline_idle_timeout_secs = 60
    try:
        await bot(
            runner_args,
            hangup_callback=hangup_callback,
            is_outbound=is_outbound,
            agent=agent,
            db_call_id=db_call_id,
            call_control_id=ccid,
            caller_history=caller_history,
            caller_phone=caller_phone,
        )
    finally:
        _active_ws.discard(session_key)


# ---------------------------------------------------------------------------
# Outbound dial
# ---------------------------------------------------------------------------

@router.post("/dial")
async def dial(
    request: Request,
    to: str = Form(...),
    from_: str | None = Form(default=None, alias="from"),
):
    if not settings.telnyx_app_id:
        raise HTTPException(500, "TELNYX_APP_ID not configured")

    to_number = to.strip()
    if not _E164_RE.match(to_number):
        raise HTTPException(400, "Phone number must be E.164 format, e.g. +923001234567")

    caller = (from_ or settings.telnyx_from_number or "").strip()
    if not caller:
        raise HTTPException(400, "No caller number — set TELNYX_FROM_NUMBER or pass 'from'")
    if not _E164_RE.match(caller):
        raise HTTPException(400, "From number must be E.164 format, e.g. +923001234567")
    if to_number == caller:
        raise HTTPException(400, "Cannot dial the bot's own number")

    # Look up agent by from number
    agent = await get_agent_by_number(caller)
    telnyx_app_id = (agent.get("telnyx_app_id") if agent else None) or settings.telnyx_app_id

    status, body = await _telnyx_post("/calls", {
        "connection_id": telnyx_app_id,
        "to": to_number,
        "from": caller,
    })
    if status >= 300:
        raise HTTPException(status, detail=body)

    outbound_ccid = (body.get("data") or {}).get("call_control_id") if isinstance(body, dict) else None
    if outbound_ccid:
        agent_id = agent.get("id") if agent else None
        asyncio.create_task(create_call(
            call_control_id=outbound_ccid,
            direction="outbound",
            from_number=caller,
            to_number=to_number,
            agent_id=agent_id,
        ))
        _outbound_registry[outbound_ccid] = (caller, time.time())
        logger.info(f"Outbound call registered: ccid={outbound_ccid[:14]}… to={to_number}")

    if "text/html" in (request.headers.get("accept") or ""):
        return RedirectResponse(url="/", status_code=303)
    return JSONResponse({"ok": True, "telnyx": body})
