"""Call log and stats APIs + frontend dashboard (migrated from server.py)."""

import re
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, Response

from app.core.database import get_calls_list, get_call_id_by_ccid, get_turns_by_call_id, delete_call, download_recording

router = APIRouter(tags=["calls"])

CALLS_DIR = Path("calls")
_TRANSCRIPT_FILE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_(\d{2}-\d{2}-\d{2})(?:_(\w+))?\.txt$")
_LINE_RE = re.compile(r"^\[(\d{2}:\d{2}:\d{2})\]\s+(USER|BOT):\s+(.*)$")


# ---------------------------------------------------------------------------
# Transcript helpers (local file fallback)
# ---------------------------------------------------------------------------

def _list_local_transcripts() -> list[dict]:
    out = []
    for path in CALLS_DIR.glob("*.txt"):
        m = _TRANSCRIPT_FILE_RE.match(path.name)
        if not m:
            continue
        date, time_s, call_id = m.groups()
        try:
            started = datetime.strptime(f"{date} {time_s.replace('-', ':')}", "%Y-%m-%d %H:%M:%S")
        except ValueError:
            started = datetime.fromtimestamp(path.stat().st_mtime)
        out.append({"file": path.name, "call_id": call_id or "", "started": started, "size": path.stat().st_size})
    out.sort(key=lambda r: r["started"], reverse=True)
    return out


def _parse_local_transcript(path: Path) -> tuple[list[dict], dict]:
    meta = {"started": None, "call_id": None}
    turns = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.rstrip()
        if not line:
            continue
        if line.startswith("#"):
            if "started" in line:
                meta["started"] = line.split("started", 1)[1].strip()
            if "Call ID" in line:
                meta["call_id"] = line.split(":", 1)[1].strip()
            continue
        m = _LINE_RE.match(line)
        if m:
            ts, speaker, text = m.groups()
            turns.append({"ts": ts, "speaker": speaker, "text": text})
    return turns, meta


# ---------------------------------------------------------------------------
# JSON APIs
# ---------------------------------------------------------------------------

@router.get("/api/stats")
async def api_stats():
    calls = await get_calls_list(limit=1000)
    inbound  = sum(1 for c in calls if c.get("direction") == "inbound")
    outbound = sum(1 for c in calls if c.get("direction") == "outbound")
    active   = sum(1 for c in calls if c.get("status") in ("in_progress", "dialing"))
    return {
        "total": len(calls),
        "inbound": inbound,
        "outbound": outbound,
        "active": active,
    }


@router.get("/api/calls")
async def api_calls():
    calls = await get_calls_list(limit=200)
    return {"calls": calls}


@router.delete("/api/calls/{call_id}", status_code=204)
async def api_delete_call(call_id: str):
    ok = await delete_call(call_id)
    if not ok:
        raise HTTPException(500, "Failed to delete call")


@router.get("/api/conversation/db/{call_id}")
async def api_conversation_db(call_id: str):
    """Return transcript turns from Supabase for a given call UUID."""
    turns = await get_turns_by_call_id(call_id)
    return {
        "call_id": call_id,
        "turns": [
            {"ts": t.get("timestamp_in_call", ""), "speaker": t["speaker"], "text": t["text"]}
            for t in turns
        ],
        "turn_count": len(turns),
    }


@router.get("/api/conversation/{filename}")
async def api_conversation_file(filename: str):
    """Return transcript turns from local file (fallback)."""
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(400, "Bad filename")
    path = CALLS_DIR / filename
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "Transcript not found")
    turns, meta = _parse_local_transcript(path)
    return {"file": filename, "started": meta.get("started"), "call_id": meta.get("call_id"), "turns": turns, "turn_count": len(turns)}


@router.get("/calls/{filename}")
async def serve_recording(filename: str):
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(400, "Bad filename")

    # Try Supabase Storage — download bytes and serve directly (no redirect, no CORS)
    audio_bytes = await download_recording(filename)
    if audio_bytes:
        return Response(
            content=audio_bytes,
            media_type="audio/mpeg",
            headers={"Content-Disposition": f'inline; filename="{filename}"'},
        )

    # Fallback: serve from local calls/ directory (legacy files)
    path = CALLS_DIR / filename
    if not path.exists():
        raise HTTPException(404, "File not found")
    media_type = "audio/mpeg" if filename.endswith(".mp3") else "application/octet-stream"
    return FileResponse(path, media_type=media_type, filename=filename)


@router.get("/health")
async def health():
    return {"status": "ok"}
