from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

from app.core.config import settings

router = APIRouter(tags=["settings"])


def _mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "•" * len(value)
    return value[:4] + "•" * (len(value) - 8) + value[-4:]


@router.get("/api/settings")
async def get_settings():
    host = settings.public_host or "localhost:7860"
    return {
        "telnyx_api_key": _mask(settings.telnyx_api_key),
        "telnyx_webhook_public_key": _mask(settings.telnyx_webhook_public_key),
        "webhook_url": f"https://{host}/webhook",
        "has_telnyx_api_key": bool(settings.telnyx_api_key),
        "has_webhook_key": bool(settings.telnyx_webhook_public_key),
    }
