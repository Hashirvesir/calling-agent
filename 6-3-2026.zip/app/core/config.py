"""Central settings — all environment variables in one place."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Supabase
    supabase_url: str
    supabase_anon_key: str
    supabase_service_role_key: str

    # AI services
    openai_api_key: str
    uplift_api_key: str

    # Telnyx
    telnyx_api_key: str = ""
    telnyx_app_id: str = ""
    telnyx_from_number: str = ""
    public_host: str = ""
    # Base64-encoded Ed25519 public key from Telnyx dashboard → API Keys → Public Key
    # Leave empty to skip signature verification (not recommended for production)
    telnyx_webhook_public_key: str = ""

    # Uplift voice IDs (overridable per-agent in DB)
    voice_urdu_default: str = "v_8eelc901"
    voice_urdu_gen_z: str = "v_kwmp7zxt"
    voice_urdu_dada_jee: str = "v_yypgzenx"
    voice_urdu_news: str = "v_30s70t3a"
    voice_sindhi: str = "v_sd0kl3m9"
    voice_balochi: str = "v_bl1de2f7"
    voice_english: str = "v_8eelc901"

    # Server
    port: int = 7860

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()
